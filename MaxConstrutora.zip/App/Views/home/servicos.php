<div class="corpo">
    <hr> 
</div> 

<input type="hidden" id="selecao_id" value="<?=$viewVar['id']?>" />
<!-- services-offer 
        ================================================== -->
<section class="services-offer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="side-navigation" >
                    <ul class="side-navigation-list">
                        <div id="tipo_ajax">
                            <!-- Aqui tem a chamada do AJAX -->
                        </div>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="offer-post" id="resposta_ajax">
                  <!-- Aqui tem a chamada do AJAX -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- End services-page section -->