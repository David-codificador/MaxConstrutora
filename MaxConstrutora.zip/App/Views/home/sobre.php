<div class="corpo">
   <hr> 
</div> 
<section class="about-alternative-section">

    <div class="container">
        <div class="row">           
            <div class="col-md-8">
                <div class="second-article">
                    <img src="upload/others/3.jpg" alt="">
                    <h2>QUEM NÓS SOMOS</h2>
                    <p>&nbsp;&nbsp; Com mais de 8 anos no mercado a Maxx Construtora proporciona total satisfação aos seus  clientes, atuando em obras de construção civil, meio fio, canaletas, sargetas, boeiros, reservatórios de água, elevatórias de esgoto e rede de esgoto.</p>
                    <p>&nbsp;&nbsp;Conta com um equipe qualificada, totalmente comprometida para que sejam respeitados os prazos e orçamentos, mantendo de forma precisa o controle total de cada etapa da obra. </p>
                    <p>&nbsp;&nbsp;Trabalhamos de forma personalizada compreendendo as necessidades de cada cliente, oferecendo todos os recursos necessários com máxima agilidade, segurança e eficiência para a realização de obras de baixa, média e alta complexidade.</p>
                </div>
            </div>   
            <div class="col-md-4">
                <!-- Nav tabs -->
                <div class="tab-posts-box">
                    <ul class="nav nav-tabs" id="myTab">
                        <li class="active">
                            <a href="#option1" data-toggle="tab">NOSSA MISSÃO</a>
                        </li>
                        <li>
                            <a href="#option2" data-toggle="tab">VISÃO</a>
                        </li>
                        <li>
                            <a href="#option3" data-toggle="tab">VALORES</a>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane active" id="option1">
                            <img src="upload/others/1.jpg" alt="">

                            <p>Construir e realizar obras com qualidade, em parceria com fornecedores e colaboradores, tendo como objetivo a satisfação do cliente.</p>
                        </div>
                        <div class="tab-pane" id="option2">
                            <img src="upload/others/2.jpg" alt="">

                            <p>Ser referência nacional no segmento de construção civil.</p>
                        </div>
                        <div class="tab-pane" id="option3">
                            <img src="upload/others/3.jpg" alt="">

                            <p>Qualidade: Total. Cliente: Satisfeito. Integridade em tudo que faz. Confiabilidade na empresa, nos clientes, nos colaboradores, nos fornecedores.</p>

                        </div>
                    </div>
                </div>
            </div>          
        </div>
    </div>
</section>
<!-- End about section -->

