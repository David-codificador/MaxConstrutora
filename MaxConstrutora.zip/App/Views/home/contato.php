<div class="corpo">
   <hr> 
</div> 



<!-- comment --><!-- contact section 
                        ================================================== -->
<section class="contact-section">
    <div class="container">
        <div class="col-md-4">
            <div class="contact-info">
                <h2>Informações de contato</h2>
                <p>Entre em contato conosco!. Retornaremos o mais breve possível.</p>
                <ul class="information-list">
                    <li><i class="fa fa-map-marker"></i><span>Ceres-GO</span></li>
                    <li><i class="fa fa-whatsapp"></i><span>(62) 98475- 5437 </span><span>(62) 99623 - 5304</span></li>
                    <li><i class="fa fa-envelope-o"></i><a href="mailto:maxuel@maxxconstrutora.com.br">maxuel@maxxconstrutora.com.br</a></li>
                </ul>						
            </div>
        </div>
        <div class="col-md-8">
            <div id="contact-form">
                <h2>ENVIE-NOS UMA MENSAGEM</h2>
                <div class="row">
                    <div class="col-md-12">
                        <input name="nome" id="nome" type="text" placeholder="Nome">
                    </div>
                     <div class="col-md-6">
                        <input name="telefone" id="telefone" type="text" placeholder="Telefone">
                    </div>
                    <div class="col-md-6">
                        <input name="email" id="email" type="text" placeholder="Email">
                    </div>
                </div>
                <textarea name="assunto" id="assunto" placeholder="Assunto"></textarea>
                <input type="button" onclick="enviarContato()" id="btn_inserir" value="Enviar Mensagem">
               <!-- <div id="msg" class="message"></div>-->
            </div>
        </div>
    </div>
</section>
<!-- End contact section -->