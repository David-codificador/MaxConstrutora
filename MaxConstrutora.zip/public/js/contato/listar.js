$(function($) {
    $("[data-toggle=confirmation]").confirmation();
});