function confirmar(link, msg){
   if(confirm(msg)){
       window.location.href = link;
   } 
}