AmCharts.translations[ "export" ][ "tr" ] = {
	"fallback.save.text": "CTRL + C panoya veriyi kopyalamak için.",
	"fallback.save.image": "Sağ tıkla -> Resim olarak kaydet... resim olarak kaydemek için.",

	"capturing.delayed.menu.label": "{{duration}}",
	"capturing.delayed.menu.title": "İptal etmek için tıkla",

	"menu.label.print": "Yazdır",
	"menu.label.undo": "Geri al",
	"menu.label.redo": "Yenile",
	"menu.label.cancel": "İptal",

	"menu.label.save.image": "Farklı kaydet ...",
	"menu.label.save.data": "Farklı kaydet ...",

	"menu.label.draw": "Açıklama ekle ...",
	"menu.label.draw.change": "Düzenle ...",
	"menu.label.draw.add": "Ekle ...",
	"menu.label.draw.shapes": "Şekil ...",
	"menu.label.draw.colors": "Renk ...",
	"menu.label.draw.widths": "Boyut ...",
	"menu.label.draw.opacities": "Saydamlık ...",
	"menu.label.draw.text": "Yazı",

	"menu.label.draw.modes": "Mod ...",
	"menu.label.draw.modes.pencil": "Kalem",
	"menu.label.draw.modes.line": "Çizgi",
	"menu.label.draw.modes.arrow": "Ok işareti",

	"label.saved.from": "Kayıt edildi: "
}
